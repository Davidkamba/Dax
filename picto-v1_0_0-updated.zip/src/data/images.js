// Free-to-use stock photos hosted on Pexels (https://www.pexels.com/license/).
// To swap any picture, just replace the URL here - every page reads from this file.
const q = "?auto=compress&cs=tinysrgb&w=900";

export const IMG = {
  workspace1: `https://images.pexels.com/photos/34150/pexels-photo.jpg${q}`,
  workspace2: `https://images.pexels.com/photos/1229861/pexels-photo-1229861.jpeg${q}`,
  workspace3: `https://images.pexels.com/photos/1229865/pexels-photo-1229865.jpeg${q}`,
  design1: `https://images.pexels.com/photos/8037008/pexels-photo-8037008.jpeg${q}`,
  design2: `https://images.pexels.com/photos/8037019/pexels-photo-8037019.jpeg${q}`,
  design3: `https://images.pexels.com/photos/8037015/pexels-photo-8037015.jpeg${q}`,
  laptop1: `https://images.pexels.com/photos/10874948/pexels-photo-10874948.jpeg${q}`,
  laptop2: `https://images.pexels.com/photos/1279109/pexels-photo-1279109.jpeg${q}`,
  laptop3: `https://images.pexels.com/photos/11208032/pexels-photo-11208032.jpeg${q}`,
  abstract: `https://images.pexels.com/photos/2473183/pexels-photo-2473183.jpeg${q}`,
  tech: `https://images.pexels.com/photos/11399091/pexels-photo-11399091.jpeg${q}`,
};
