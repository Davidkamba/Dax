import {
  faPenRuler,
  faMobileScreenButton,
  faCode,
  faChartLine,
  faPalette,
  faRocket,
} from "@fortawesome/free-solid-svg-icons";
import { IMG } from "./images";

export const services = [
  {
    id: 1,
    icon: faPenRuler,
    title: "UX Research & Strategy",
    image: IMG.design1,
    description:
      "User interviews, journey maps and wireframes that turn real needs into a clear product direction.",
  },
  {
    id: 2,
    icon: faPalette,
    title: "UI & Visual Design",
    image: IMG.design2,
    description:
      "Consistent, modern interfaces with carefully chosen colour, type and layout systems.",
  },
  {
    id: 3,
    icon: faCode,
    title: "Web Development",
    image: IMG.laptop1,
    description:
      "Fast, responsive and accessible websites and web apps built with modern technologies.",
  },
  {
    id: 4,
    icon: faMobileScreenButton,
    title: "Mobile App Design",
    image: IMG.design3,
    description:
      "Touch-friendly app screens and prototypes that feel natural on every device size.",
  },
  {
    id: 5,
    icon: faChartLine,
    title: "Dashboards & Analytics",
    image: IMG.laptop2,
    description:
      "Clear data visualisation and admin dashboards that help teams make better decisions.",
  },
  {
    id: 6,
    icon: faRocket,
    title: "Launch & Support",
    image: IMG.tech,
    description:
      "Testing, deployment and ongoing improvements so your product keeps performing after launch.",
  },
];

export const projects = [
  { id: 1, image: IMG.laptop1, category: "WEB DEVELOPMENT", title: "Business Website", description: "A clean, fast company website with a strong call to action and mobile-first layout." },
  { id: 2, image: IMG.design1, category: "UI-UX DESIGN", title: "Product Admin Dashboard", description: "An intuitive dashboard for product management, built for clarity and efficiency." },
  { id: 3, image: IMG.design2, category: "MOBILE APP", title: "Delivery App Interface", description: "End-to-end app screens covering onboarding, ordering and live tracking." },
  { id: 4, image: IMG.workspace2, category: "BRANDING", title: "Brand Identity Kit", description: "Logo, colour palette and typography guidelines for a growing local brand." },
  { id: 5, image: IMG.laptop2, category: "WEB DEVELOPMENT", title: "Online Store", description: "A responsive e-commerce experience with simple checkout and product filtering." },
  { id: 6, image: IMG.abstract, category: "UI-UX DESIGN", title: "Analytics Platform", description: "Interactive charts and widgets that make complex data easy to read." },
  { id: 7, image: IMG.design3, category: "MOBILE APP", title: "Fitness Tracker App", description: "A motivating, easy-to-scan interface for tracking workouts and goals." },
  { id: 8, image: IMG.workspace3, category: "BRANDING", title: "Startup Landing Page", description: "A high-converting landing page with a bold visual story and clear messaging." },
  { id: 9, image: IMG.laptop3, category: "WEB DEVELOPMENT", title: "Portfolio Template", description: "A flexible portfolio system with reusable sections and quick editing." },
];

export const posts = [
  { id: 1, image: IMG.workspace1, date: "12 Sep, 2026", comments: 24, category: "Design", title: "Designing Engaging User Interfaces for Modern Web Apps", excerpt: "Practical principles for building interfaces people actually enjoy using." },
  { id: 2, image: IMG.design1, date: "28 Aug, 2026", comments: 18, category: "UX", title: "Tips for Effective Dashboard Layouts and Usability", excerpt: "How to organise data so the most important numbers are seen first." },
  { id: 3, image: IMG.abstract, date: "14 Aug, 2026", comments: 31, category: "Data", title: "How to Visualize Data for Better Product Decisions", excerpt: "Choosing the right chart and keeping visuals honest and readable." },
  { id: 4, image: IMG.laptop3, date: "02 Aug, 2026", comments: 12, category: "Development", title: "Responsive Design: Adapting to All Devices Seamlessly", excerpt: "A simple approach to layouts that look great from phone to desktop." },
  { id: 5, image: IMG.design2, date: "19 Jul, 2026", comments: 9, category: "Workflow", title: "Streamlining Workflows with UI/UX Best Practices", excerpt: "Habits and tools that help design and development teams ship faster." },
  { id: 6, image: IMG.tech, date: "05 Jul, 2026", comments: 15, category: "Performance", title: "Optimizing Interface Components for Performance", excerpt: "Small changes that make websites noticeably faster and smoother." },
];
