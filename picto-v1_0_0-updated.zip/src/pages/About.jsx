import { Link } from "react-router-dom";
import PageHeader from "../components/common/pageHeader/PageHeader";
import SafeImg from "../components/common/safeImg/SafeImg";
import WorkProcess from "../components/workProcess/WorkProcess";
import WorkTogether from "../components/workTogether/WorkTogether";
import personA from "../assets/images/person2.png";
import personB from "../assets/images/person.png";
import { IMG } from "../data/images";

const skills = [
  { name: "UI / UX Design", value: 95 },
  { name: "Web Development", value: 90 },
  { name: "Brand Identity", value: 80 },
  { name: "Project Management", value: 85 },
];

const stats = [
  { label: "Experience", value: "15 Y." },
  { label: "Projects Completed", value: "250+" },
  { label: "Happy Clients", value: "58" },
];

const gallery = [IMG.workspace1, IMG.workspace2, IMG.laptop2, IMG.design1];

const About = () => {
  return (
    <div>
      <PageHeader
        title="About Me"
        subtitle="Get to know the person behind the designs - my story, my skills and how I like to work."
        image={IMG.workspace3}
      />

      <div className="content px-4 py-12 md:py-20 grid lg:grid-cols-2 gap-10 items-center">
        <div className="grid grid-cols-2 gap-4">
          <div className="rounded-2xl bg-[#f0f1f3] overflow-hidden aspect-[3/4]">
            <img src={personA} alt="David James" className="w-full h-full object-cover object-top" />
          </div>
          <div className="rounded-2xl bg-white shadow-xl overflow-hidden aspect-[3/4] mt-8">
            <img src={personB} alt="David James" className="w-full h-full object-cover object-top" />
          </div>
        </div>
        <div className="max-lg:text-center">
          <h2 className="text-2xl sm:text-4xl font-semibold mb-6">
            I am a Professional User Experience Designer
          </h2>
          <p className="text-gray-600 mb-4">
            I design and develop services for customers, specializing in
            creating stylish, modern websites, web services and online stores.
            My passion is to design digital user experiences that are simple to
            use and enjoyable to look at.
          </p>
          <p className="text-gray-600 mb-8">
            Based in Maiduguri, Borno State, I work with clients and teams to
            turn ideas into products - from research and wireframes to
            development and launch.
          </p>
          <div className="flex max-lg:justify-center gap-3">
            <Link to="/portfolio" className="btn btn-primary px-6">
              View Portfolio
            </Link>
            <Link to="/contact" className="btn bg-white px-6">
              Contact Me
            </Link>
          </div>
        </div>
      </div>

      <div className="bg-soft-white">
        <div className="content px-4 py-12 md:py-20 grid lg:grid-cols-2 gap-10 items-center">
          <div>
            <p className="section-title mb-8 max-lg:text-center">My Skills</p>
            {skills.map((s) => (
              <div key={s.name} className="mb-5">
                <div className="flex justify-between text-sm font-medium mb-2">
                  <span>{s.name}</span>
                  <span>{s.value}%</span>
                </div>
                <div className="h-2 rounded-full bg-white">
                  <div
                    className="h-2 rounded-full bg-picto-primary"
                    style={{ width: `${s.value}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
          <div className="grid grid-cols-3 gap-3">
            {stats.map((s) => (
              <div key={s.label} className="bg-white rounded-xl p-4 md:p-8 text-center shadow">
                <p className="text-2xl md:text-4xl font-semibold">{s.value}</p>
                <p className="text-xs md:text-sm text-gray-500 mt-2">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <WorkProcess />

      <div className="content px-4 pb-16">
        <p className="section-title text-center mb-10">Life at Work</p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {gallery.map((g, i) => (
            <SafeImg key={i} src={g} alt="Workspace" className="w-full h-40 md:h-56 object-cover rounded-xl" />
          ))}
        </div>
      </div>

      <div className="bg-gray-900">
        <WorkTogether />
      </div>
    </div>
  );
};

export default About;
