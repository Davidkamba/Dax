import PageHeader from "../components/common/pageHeader/PageHeader";
import Portfolio from "../components/portfolio/Portfolio";
import WorkTogether from "../components/workTogether/WorkTogether";
import { IMG } from "../data/images";

const PortfolioPage = () => {
  return (
    <div>
      <PageHeader
        title="Portfolio"
        subtitle="A selection of recent work across web, mobile and brand design."
        image={IMG.laptop2}
      />
      <Portfolio filters showMore={false} showHeading={false} />
      <div className="bg-gray-900">
        <WorkTogether />
      </div>
    </div>
  );
};

export default PortfolioPage;
