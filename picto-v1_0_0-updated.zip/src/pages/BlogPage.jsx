import PageHeader from "../components/common/pageHeader/PageHeader";
import MonoBlog from "../components/blog/MonoBlog";
import SafeImg from "../components/common/safeImg/SafeImg";
import { posts } from "../data/content";
import { IMG } from "../data/images";

const BlogPage = () => {
  const [featured, ...rest] = posts;
  return (
    <div>
      <PageHeader
        title="Blog"
        subtitle="Insights on design, development and the latest industry trends."
        image={IMG.workspace1}
      />
      <div className="content px-4 py-12 md:py-20">
        <div className="grid lg:grid-cols-2 gap-8 items-center bg-white rounded-2xl overflow-hidden shadow-xl mb-12">
          <SafeImg
            src={featured.image}
            alt={featured.title}
            className="w-full h-64 lg:h-full object-cover"
          />
          <div className="p-6 md:p-10">
            <p className="text-xs font-semibold text-picto-primary uppercase mb-2">
              Featured / {featured.category}
            </p>
            <h2 className="text-2xl md:text-3xl font-semibold mb-3">
              {featured.title}
            </h2>
            <p className="text-gray-500 mb-4">{featured.excerpt}</p>
            <p className="text-sm text-gray-400">
              {featured.date} / {featured.comments} Comments
            </p>
          </div>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {rest.map((p) => (
            <MonoBlog key={p.id} data={p} />
          ))}
        </div>
        <div className="mt-16 rounded-2xl bg-soft-white p-8 md:p-12 text-center">
          <p className="text-2xl md:text-3xl font-semibold mb-3">Stay in the loop</p>
          <p className="text-gray-500 mb-6">
            Get new articles straight to your inbox.
          </p>
          <a
            href="mailto:Davidkamba2000@gmail.com?subject=Blog%20subscription"
            className="btn btn-primary px-6"
          >
            Subscribe by Email
          </a>
        </div>
      </div>
    </div>
  );
};

export default BlogPage;
