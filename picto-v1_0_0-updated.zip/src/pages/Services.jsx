import PageHeader from "../components/common/pageHeader/PageHeader";
import ServiceCards from "../components/services/ServiceCards";
import Profession from "../components/profession/Profession";
import WorkProcess from "../components/workProcess/WorkProcess";
import WorkTogether from "../components/workTogether/WorkTogether";
import { IMG } from "../data/images";

const Services = () => {
  return (
    <div>
      <PageHeader
        title="Services"
        subtitle="Design, development and support - everything you need to launch a great digital product."
        image={IMG.design2}
      />
      <ServiceCards showHeading={false} />
      <div className="bg-soft-white">
        <Profession />
      </div>
      <WorkProcess />
      <div className="bg-gray-900">
        <WorkTogether />
      </div>
    </div>
  );
};

export default Services;
