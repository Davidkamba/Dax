import PageHeader from "../components/common/pageHeader/PageHeader";
import Contact from "../components/contact/Contact";
import { IMG } from "../data/images";

const ContactPage = () => {
  return (
    <div>
      <PageHeader
        title="Contact"
        subtitle="Have a project in mind? Reach out and let's talk about it."
        image={IMG.workspace2}
      />
      <div className="content px-4 py-12 md:py-16 mb-16">
        <p className="section-title text-center mb-8">Find Me</p>
        <iframe
          title="Old Airport, Maiduguri, Borno State"
          src="https://www.google.com/maps?q=Old+Airport,+Maiduguri,+Borno+State&output=embed"
          className="w-full h-80 md:h-96 rounded-2xl border-0 shadow-xl"
          loading="lazy"
        />
      </div>
      <Contact />
    </div>
  );
};

export default ContactPage;
