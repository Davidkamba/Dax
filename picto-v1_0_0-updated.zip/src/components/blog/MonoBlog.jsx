import SafeImg from "../common/safeImg/SafeImg";

const MonoBlog = ({ data }) => {
  return (
    <div className="overflow-hidden rounded-lg border border-gray-100 hover:shadow-2xl bg-white shadow-gray-300 transition-all duration-300 h-full">
      <SafeImg
        src={data?.image}
        alt={data?.title || "Blog"}
        className="w-full h-56.5 object-cover"
      />
      <div className="m-6">
        {data?.category && (
          <p className="text-[11px] font-semibold text-picto-primary mb-1 uppercase">
            {data.category}
          </p>
        )}
        <p className="text-[10px] xs:text-[14px] font-normal text-gray-400 ">
          {data?.date} / {data?.comments} Comments
        </p>
        <p className="text-[14px] xs:text-lg font-medium text-[#333333]">
          {data?.title.length > 60
            ? `${data?.title.slice(0, 60)}...`
            : data?.title}
        </p>
        {data?.excerpt && (
          <p className="text-sm text-gray-500 mt-2">{data.excerpt}</p>
        )}
      </div>
    </div>
  );
};

export default MonoBlog;
