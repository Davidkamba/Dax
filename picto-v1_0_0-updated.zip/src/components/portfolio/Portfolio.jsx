import { useState } from "react";
import { Link } from "react-router-dom";
import Projects from "./Projects";
import { projects } from "../../data/content";

const categories = ["ALL", ...new Set(projects.map((p) => p.category))];

// limit: show only the first N projects (home page). filters: show category tabs (portfolio page).
const Portfolio = ({ limit, filters = false, showMore = true, showHeading = true }) => {
  const [active, setActive] = useState("ALL");
  const list = projects.filter((p) => active === "ALL" || p.category === active);
  const shown = limit ? list.slice(0, limit) : list;

  return (
    <div
      className="content mt-10 md:mt-15 xl:mt-25 mb-10 md:mb-25 max-xxl:p-2"
      id="portfolio"
    >
      {showHeading && (
        <div className="xl:mb-17.5 mb-5">
          <div className="max-sm:px-2 text-center mx-auto max-w-144.25">
            <p className="section-title ">Portfolio</p>
            <p className="font-normal text-[18px] max-sm:text-[14px] pt-6 text-gray-400">
              Here's a selection of my recent work, showcasing my skills in
              creating user-centric and visually appealing interfaces.
            </p>
          </div>
        </div>
      )}
      {filters && (
        <div className="flex flex-wrap justify-center gap-2 mb-10 px-2">
          {categories.map((c) => (
            <button
              key={c}
              onClick={() => setActive(c)}
              className={`btn btn-sm md:btn-md ${
                active === c ? "btn-primary" : "bg-white"
              }`}
            >
              {c}
            </button>
          ))}
        </div>
      )}
      <div className="mx-auto flex justify-center">
        <div className="grid xl:grid-cols-3 md:grid-cols-2 gap-6">
          {shown.map((data) => (
            <Projects data={data} key={data.id} />
          ))}
        </div>
      </div>
      {showMore && (
        <div className="text-center">
          <Link
            to="/portfolio"
            className="btn btn-primary py-3 px-6 mt-12.5 text-center text-[16px] font-semibold"
          >
            More Project
          </Link>
        </div>
      )}
    </div>
  );
};

export default Portfolio;
