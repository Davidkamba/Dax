import { faArrowRight } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Link } from "react-router-dom";
import SafeImg from "../common/safeImg/SafeImg";

const Projects = ({ data }) => {
  return (
    <div className="max-w-106 w-full overflow-hidden rounded-lg bg-white hover:shadow-2xl duration-300 transition-all shadow-gray-300 border border-gray-200">
      <SafeImg
        src={data?.image}
        alt={`${data?.title} image`}
        className="w-full h-56 object-cover"
      />
      <div className="p-4 xs:p-8">
        <p className="text-gray-400 text-xs font-medium">{data?.category}</p>
        <p className="text-gray-900 text-md xxs:text-lg font-semibold pt-1 mb-3">
          {data?.title}
        </p>
        <p
          style={{ lineHeight: "20px", letterSpacing: "0%" }}
          className="text-gray-600 text-xs xxs:text-[14px] text-wrap"
        >
          {data?.description}
        </p>
        <Link
          to="/contact"
          className="btn hover:border-picto-primary hover:text-picto-primary bg-white text-sm xs:text-[16px] font-semibold hover:gap-3 xs:hover:gap-4 transition-all duration-300 mt-5 px-6"
        >
          Case Study
          <span className="ms-1 xs:ms-3">
            <FontAwesomeIcon icon={faArrowRight} />
          </span>
        </Link>
      </div>
    </div>
  );
};

export default Projects;
