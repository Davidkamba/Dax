import { Link } from "react-router-dom";
import SafeImg from "../safeImg/SafeImg";

const PageHeader = ({ title, subtitle, image }) => {
  return (
    <div className="introduction-profile-background">
      <div className="content px-4 py-12 md:py-20 grid lg:grid-cols-2 gap-8 items-center">
        <div className="max-lg:text-center">
          <p className="text-sm text-gray-500 mb-4">
            <Link to="/" className="hover:text-picto-primary">
              Home
            </Link>{" "}
            / <span className="text-picto-primary">{title}</span>
          </p>
          <h1 className="section-title">{title}</h1>
          <p className="mt-6 text-gray-500 text-sm md:text-lg max-w-xl max-lg:mx-auto">
            {subtitle}
          </p>
        </div>
        {image && (
          <SafeImg
            src={image}
            alt={title}
            className="w-full h-56 md:h-80 object-cover rounded-3xl shadow-2xl shadow-gray-200"
          />
        )}
      </div>
    </div>
  );
};

export default PageHeader;
