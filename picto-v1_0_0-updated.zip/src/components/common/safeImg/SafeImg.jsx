import { useState } from "react";

// <img> that falls back to a soft gradient block if the remote photo can't load.
const SafeImg = ({ src, alt = "", className = "", ...rest }) => {
  const [failed, setFailed] = useState(false);
  if (failed) {
    return (
      <div
        role="img"
        aria-label={alt}
        className={`${className} bg-linear-to-br from-purple-200 via-pink-100 to-teal-100`}
      />
    );
  }
  return (
    <img
      src={src}
      alt={alt}
      loading="lazy"
      className={className}
      onError={() => setFailed(true)}
      {...rest}
    />
  );
};

export default SafeImg;
