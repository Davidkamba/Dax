import { Link } from "react-router-dom";
import logo from "../../../assets/logo.png";

/* Footer nabLinks */
const navItems = [
  { id: 1, name: "Home", to: "/" },
  { id: 2, name: "About", to: "/about" },
  { id: 3, name: "Services", to: "/services" },
  { id: 4, name: "Portfolio", to: "/portfolio" },
  { id: 5, name: "Blog", to: "/blog" },
  { id: 6, name: "Contact", to: "/contact" },
];
const copyrightYear = new Date().getFullYear();

const Footer = () => {
  return (
    <div className="pt-25 md:pt-40 content max-2xl:px-3">
      <div className="flex max-md:flex-col justify-between mx-0 items-center h-full w-full text-neutral-200">
        <Link to="/" className="flex items-center border-0">
          <img src={logo} className="h-8 sm:h-14 rounded-2xl" alt="logo" />
          <p className="text-3xl sm:text-[32px] my-auto ms-[12px] font-semibold">
            DAVID JAMES
          </p>
        </Link>
        <div className="mx-7 max-md:my-7 text-center">
          {navItems.map((item) => (
            <Link
              key={item.id}
              className="mx-2 group inline-block relative w-fit text-[12px] sm:text-[16px]"
              to={item.to}
            >
              {item.name}
              <span className="absolute left-0 bottom-0 h-0.5 w-full bg-white scale-x-0 duration-300 group-hover:scale-x-100"></span>
            </Link>
          ))}
        </div>
        <p className="text-[12px] sm:text-[16px]">
          Copyright &copy; {copyrightYear} DAVID JAMES.
        </p>
      </div>
      <p className="text-white text-center max-xs:text-[12px] max-md:text-[14px] w-full py-10">
        Developed with ❤️ by{" "}
        <a
          href="https://www.themewagon.com"
          className="underline font-bold"
          target="_blank"
        >
          ThemeWagon
        </a>
      </p>
    </div>
  );
};

export default Footer;
