import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import SafeImg from "../common/safeImg/SafeImg";
import { services } from "../../data/content";

const ServiceCards = ({ limit, showHeading = true }) => {
  const list = limit ? services.slice(0, limit) : services;
  return (
    <div className="content px-4 py-10 md:py-16">
      {showHeading && (
        <div className="text-center max-w-144.25 mx-auto mb-10 md:mb-16">
          <p className="section-title">Services</p>
          <p className="pt-6 text-gray-400 text-sm md:text-lg">
            Everything you need to take an idea from first sketch to a polished,
            working product.
          </p>
        </div>
      )}
      <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6">
        {list.map((s) => (
          <div
            key={s.id}
            className="group bg-white rounded-lg overflow-hidden border border-gray-200 hover:shadow-2xl shadow-gray-300 duration-300"
          >
            <div className="relative">
              <SafeImg
                src={s.image}
                alt={s.title}
                className="w-full h-52 object-cover"
              />
              <span className="absolute -bottom-6 start-6 w-12 h-12 rounded-lg bg-picto-primary text-white flex items-center justify-center shadow-lg">
                <FontAwesomeIcon icon={s.icon} />
              </span>
            </div>
            <div className="p-6 pt-10">
              <p className="text-xl font-semibold text-gray-900 mb-2">
                {s.title}
              </p>
              <p className="text-gray-600 text-sm md:text-[16px]">
                {s.description}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ServiceCards;
