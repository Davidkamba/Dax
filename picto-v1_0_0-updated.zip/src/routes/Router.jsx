import { lazy, Suspense } from "react";
import { createBrowserRouter } from "react-router-dom";
import Loading from "../components/common/loading/Loading";
const Main = lazy(() => import("../layouts/Main"));
const Home = lazy(() => import("../pages/Home"));
const About = lazy(() => import("../pages/About"));
const Services = lazy(() => import("../pages/Services"));
const PortfolioPage = lazy(() => import("../pages/PortfolioPage"));
const BlogPage = lazy(() => import("../pages/BlogPage"));
const ContactPage = lazy(() => import("../pages/ContactPage"));

const repoName = import.meta.env.VITE_REPO_NAME || "";

const page = (Component) => (
  <Suspense fallback={<Loading />}>
    <Component />
  </Suspense>
);

export const router = createBrowserRouter(
  [
    {
      path: `/`,
      element: (
        <Suspense fallback={<Loading />}>
          <Main />
        </Suspense>
      ),
      children: [
        { path: "/", element: page(Home) },
        { path: "/about", element: page(About) },
        { path: "/services", element: page(Services) },
        { path: "/portfolio", element: page(PortfolioPage) },
        { path: "/blog", element: page(BlogPage) },
        { path: "/contact", element: page(ContactPage) },
      ],
    },
  ],
  { basename: `/${repoName}` }
);
